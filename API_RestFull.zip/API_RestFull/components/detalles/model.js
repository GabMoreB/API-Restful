const mongoose = require('mongoose')

const Detalle = mongoose.model('detalles', { idLibro: Number, nombreLibro: String, ValorUnitario: Number, Cantidad: Number })

module.exports = Detalle

