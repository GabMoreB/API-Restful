const express = require('express')
const router = express.Router()
const { createDetalle } = require('./actions')

// GET by ID
router.get('/:id', (req, res) => {
  res.send({})
})

// POST Create a detalle
router.post('/', createDetalle)

// PUT Update a detalle's info
router.put('/:id', (req, res) => {
  res.send({})
})

// DELETE by ID
router.delete('/:id', (req, res) => {
  res.send('Detalle deleted successfully!')
})

module.exports = router