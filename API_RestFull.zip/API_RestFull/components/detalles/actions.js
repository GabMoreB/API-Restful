const Detalle = require('./model')

const createDetalle = (req, res) => {
  const newDetalle = new Detalle(req.body)
  newDetalle.save((error, DetalleSaved) => {
    if (error) {
      console.error('Error saving detalle ', error)
      res.status(500).send(error)
    } else {
      res.send(DetalleSaved)
    }
  })
}

module.exports = { createDetalle }

