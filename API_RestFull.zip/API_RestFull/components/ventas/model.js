const mongoose = require('mongoose')

const Venta = mongoose.model('ventas', { fecha: Date, total: Number, identificacion: String})

module.exports = Venta;

