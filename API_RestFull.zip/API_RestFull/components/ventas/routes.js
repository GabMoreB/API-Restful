const express = require('express')
const router = express.Router()
const { createVenta } = require('./actions')

// GET by ID
router.get('/:id', (req, res) => {
  res.send({})
})

// POST Create a Venta
router.post('/', createVenta)

// PUT Update a Venta's info
router.put('/:id', (req, res) => {
  res.send({})
})

// DELETE by ID
router.delete('/:id', (req, res) => {
  res.send('Venta deleted successfully!')
})

module.exports = router