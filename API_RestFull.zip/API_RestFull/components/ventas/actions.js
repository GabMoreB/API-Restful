const Venta = require('./model')

const createVenta = (req, res) => {
  const newVenta = new Venta(req.body)
  newVenta.save((error, ventaSaved) => {
    if (error) {
      console.error('Error saving venta ', error)
      res.status(500).send(error)
    } else {
      res.send(ventaSaved)
    }
  })
}

module.exports = { createVenta }
